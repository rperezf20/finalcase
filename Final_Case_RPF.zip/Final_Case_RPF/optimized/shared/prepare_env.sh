#!/bin/bash


hdfs dfs -rm -r /Credit_Card_System/optimized

hdfs dfs -mkdir -p /Credit_Card_System/optimized/oozie

hdfs dfs -mkdir -p /Credit_Card_System/optimized/hive

hdfs dfs -put -f ./Final_Case_RPF/optimized/oozie/wf_* /Credit_Card_System/optimized/oozie/

hdfs dfs -put -f ./Final_Case_RPF/optimized/hive/ins_* /Credit_Card_System/optimized/hive/

hdfs dfs -ls /Credit_Card_System/optimized/
