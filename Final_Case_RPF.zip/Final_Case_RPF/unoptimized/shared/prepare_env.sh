#!/bin/bash


hdfs dfs -rm -r /Credit_Card_System/unoptimized

hdfs dfs -mkdir -p /Credit_Card_System/unoptimized/oozie

hdfs dfs -mkdir -p /Credit_Card_System/unoptimized/hive

hdfs dfs -put -f ./Final_Case_RPF/unoptimized/oozie/wf_* /Credit_Card_System/unoptimized/oozie/

hdfs dfs -put -f ./Final_Case_RPF/unoptimized/hive/ins_* /Credit_Card_System/unoptimized/hive/

hdfs dfs -ls /Credit_Card_System/unoptimized/
