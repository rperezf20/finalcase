#!/bin/bash

hive -f ./Final_Case_RPF/shared/hive/cr_database.hql
