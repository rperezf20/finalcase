#!/bin/bash

echo "Importing cdw_sapp.cdw_sapp_branch Table..." && sleep 3
echo ""


sqoop import \
--driver com.mysql.jdbc.Driver \
--connect jdbc:mysql://localhost/cdw_sapp \
--query "SELECT branch_code, branch_name, branch_street, branch_city, branch_state, IF(branch_zip IS NULL, 999999, branch_zip) AS br_zip, \
CONCAT('(', SUBSTR(branch_phone,1,3),')',SUBSTR(branch_phone,4,3),'-',SUBSTR(branch_phone,7,4)) AS br_phone, last_updated FROM cdw_sapp_branch WHERE \$CONDITIONS" \
--fields-terminated-by '\t' \
--delete-target-dir \
--target-dir '/Credit_Card_System/Branch' \
-m 1

echo ""
echo "Importing cdw_sapp.cdw_sapp_customer Table..." && sleep 3
echo ""

sqoop import \
--driver com.mysql.jdbc.Driver \
--connect jdbc:mysql://localhost/cdw_sapp \
--query "SELECT ssn, CONCAT(UPPER(SUBSTR(first_name,1,1)), LOWER(RIGHT(first_name, LENGTH(first_name)-1))) AS fn, LOWER(middle_name) AS mn \
, CONCAT(UPPER(SUBSTR(last_name,1,1)), LOWER(RIGHT(last_name, LENGTH(last_name)-1))) AS ln, credit_card_no, CONCAT(street_name, ', ', apt_no) AS apt_street \
, cust_city, cust_state, cust_country, CONVERT(cust_zip, UNSIGNED INTEGER) cz, CONCAT(SUBSTR(cust_phone,1,3),'-',SUBSTR(cust_phone,4,4)) AS cu_phone, cust_email, \
last_updated FROM cdw_sapp_customer WHERE \$CONDITIONS" \
--fields-terminated-by '\t' \
--delete-target-dir \
--target-dir '/Credit_Card_System/Customer' \
-m 1

echo ""
echo "Importing cdw_sapp.cdw_sapp_creditcard Table..." && sleep 3
echo ""

sqoop import \
--driver com.mysql.jdbc.Driver \
--connect jdbc:mysql://localhost/cdw_sapp \
--query "SELECT credit_card_no, DATE_FORMAT(CONCAT(year, '-', month, '-', day), GET_FORMAT(DATE, 'INTERNAL')) AS timeid, cust_ssn, branch_code, transaction_type, \
transaction_value, transaction_id, last_updated FROM cdw_sapp_creditcard WHERE \$CONDITIONS" \
--fields-terminated-by '\t' \
--delete-target-dir \
--target-dir '/Credit_Card_System/CreditCard' \
-m 1

echo ""
echo "Importing cdw_sapp.cdw_sapp_creditcard (only values for Time table) Table..." && sleep 3
echo ""

sqoop import \
--driver com.mysql.jdbc.Driver \
--connect jdbc:mysql://localhost/cdw_sapp \
--query "SELECT transaction_id, DATE_FORMAT(CONCAT(year, '-', month, '-', day), GET_FORMAT(DATE, 'INTERNAL')) AS timeid, day, month, CEILING(month/3) AS quarter, \
year, last_updated FROM cdw_sapp_creditcard WHERE \$CONDITIONS" \
--fields-terminated-by '\t' \
--delete-target-dir \
--target-dir '/Credit_Card_System/Time' \
-m 1


