#!/bin/bash

echo "Deleting importBranch Job..."  && sleep 3
echo ""

sqoop job \
--meta-connect jdbc:hsqldb:hsql://localhost:16000/sqoop \
--delete importBranchOpt

echo ""
echo "Deleting importCustomer Job..." && sleep 3
echo ""

sqoop job \
--meta-connect jdbc:hsqldb:hsql://localhost:16000/sqoop \
--delete importCustomerOpt

echo ""
echo "Deleting importCreditCard Job..." && sleep 3
echo ""

sqoop job \
--meta-connect jdbc:hsqldb:hsql://localhost:16000/sqoop \
--delete importCreditCardOpt

echo ""
echo "Deleting importTime Job..." && sleep 3
echo ""

sqoop job \
--meta-connect jdbc:hsqldb:hsql://localhost:16000/sqoop \
--delete importTimeOpt

echo""

sqoop job \
--meta-connect jdbc:hsqldb:hsql://localhost:16000/sqoop \
--list
