#!/bin/bash


hdfs dfs -rm -r /Credit_Card_System/optimized

hdfs dfs -mkdir -p /Credit_Card_System/optimized/oozie

hdfs dfs -mkdir -p /Credit_Card_System/optimized/hive

hdfs dfs -put -f ./Final_Case_RPF/2.2.4_POM/shared/java-json.jar /user/oozie/share/lib/lib_20161025075203/sqoop/

hdfs dfs -put -f ./Final_Case_RPF/2.2.4_POM/oozie/wf_* /Credit_Card_System/optimized/oozie/

hdfs dfs -put -f ./Final_Case_RPF/2.2.4_POM/hive/ins_* /Credit_Card_System/optimized/hive/

hdfs dfs -ls /Credit_Card_System/optimized/
