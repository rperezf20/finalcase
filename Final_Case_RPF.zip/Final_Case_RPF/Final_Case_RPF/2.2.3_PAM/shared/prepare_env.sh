#!/bin/bash


hdfs dfs -rm -r /Credit_Card_System/unoptimized

hdfs dfs -mkdir -p /Credit_Card_System/unoptimized/oozie

hdfs dfs -mkdir -p /Credit_Card_System/unoptimized/hive

hdfs dfs -put -f ./Final_Case_RPF/2.2.3_PAM/shared/java-json.jar /user/oozie/share/lib/lib_20161025075203/sqoop/

hdfs dfs -put -f ./Final_Case_RPF/2.2.3_PAM/oozie/wf_* /Credit_Card_System/unoptimized/oozie/

hdfs dfs -put -f ./Final_Case_RPF/2.2.3_PAM/hive/ins_* /Credit_Card_System/unoptimized/hive/

hdfs dfs -ls /Credit_Card_System/unoptimized/
