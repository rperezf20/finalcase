#!/bin/bash

hive -f ./Final_Case_RPF/shared/hive/cr_ext_branch.hql

hive -f ./Final_Case_RPF/shared/hive/cr_ext_customer.hql

hive -f ./Final_Case_RPF/shared/hive/cr_ext_credit_card.hql

hive -f ./Final_Case_RPF/shared/hive/cr_ext_time.hql
