#!/bin/bash

echo "Creating importBranchOpt Job..."

sqoop job \
--meta-connect jdbc:hsqldb:hsql://localhost:16000/sqoop \
--create importBranchOpt \
-- import \
--connect jdbc:mysql://localhost/cdw_sapp \
--driver com.mysql.jdbc.Driver \
--append \
--query \
"SELECT branch_code, branch_name, branch_street, branch_city, branch_state, \
IF(branch_zip IS NULL, 999999, branch_zip) AS br_zip, \
CONCAT('(', SUBSTR(branch_phone,1,3),')',SUBSTR(branch_phone,4,3),'-',SUBSTR(branch_phone,7,4)) AS br_phone, \
 last_updated \
 FROM cdw_sapp_branch WHERE \$CONDITIONS" \
--incremental lastmodified \
--check-column last_updated \
--last-value '0000-01-01 00:00:00'	\
--target-dir '/Credit_Card_System/Branch/' \
--fields-terminated-by '\t' \
-m 1

echo "Creating importCustomerOpt Job..."

sqoop job \
--meta-connect jdbc:hsqldb:hsql://localhost:16000/sqoop \
--create importCustomerOpt \
-- import \
--connect jdbc:mysql://localhost/cdw_sapp \
--driver com.mysql.jdbc.Driver \
--append \
--query \
"SELECT ssn, CONCAT(UPPER(SUBSTR(first_name,1,1)), LOWER(RIGHT(first_name, LENGTH(first_name)-1))) AS fn, \
LOWER(middle_name) AS mn, CONCAT(UPPER(SUBSTR(last_name,1,1)), LOWER(RIGHT(last_name, LENGTH(last_name)-1))) AS ln, \
credit_card_no, CONCAT(apt_no, ', ', street_name) AS apt_street, cust_city, cust_state, cust_country, \
CONVERT(cust_zip, UNSIGNED INTEGER) cz, CONCAT(SUBSTR(cust_phone,1,3),'-',SUBSTR(cust_phone,4,4)) AS cu_phone, \
cust_email, last_updated \
FROM cdw_sapp_customer WHERE \$CONDITIONS" \
--incremental lastmodified \
--check-column last_updated \
--last-value '0000-01-01 00:00:00'	\
--target-dir '/Credit_Card_System/Customer/' \
--fields-terminated-by '\t' \
-m 1

echo "Creating importCreditCardOpt Job..."

sqoop job \
--meta-connect jdbc:hsqldb:hsql://localhost:16000/sqoop \
--create importCreditCardOpt \
-- import \
--connect jdbc:mysql://localhost/cdw_sapp \
--driver com.mysql.jdbc.Driver \
--append \
--query \
"SELECT credit_card_no, DATE_FORMAT(CONCAT(year, '-', month, '-', day), GET_FORMAT(DATE, 'INTERNAL')) AS timeid, \
cust_ssn, branch_code, transaction_type, transaction_value, transaction_id, last_updated \
FROM cdw_sapp_creditcard WHERE \$CONDITIONS" \
--incremental lastmodified \
--check-column last_updated \
--last-value '0000-01-01 00:00:00'	\
--target-dir '/Credit_Card_System/CreditCard/' \
--fields-terminated-by '\t' \
-m 1

echo "Creating importTimeOpt Job..."

sqoop job \
--meta-connect jdbc:hsqldb:hsql://localhost:16000/sqoop \
--create importTimeOpt \
-- import \
--connect jdbc:mysql://localhost/cdw_sapp \
--driver com.mysql.jdbc.Driver \
--query \
"SELECT transaction_id, DATE_FORMAT(CONCAT(year, '-', month, '-', day), GET_FORMAT(DATE, 'INTERNAL')) AS timeid, \
day, month, CEILING(month/3) AS quarter, year, last_updated \
FROM cdw_sapp_creditcard WHERE \$CONDITIONS" \
--incremental lastmodified \
--check-column last_updated \
--last-value '0000-01-01 00:00:00' \
--target-dir '/Credit_Card_System/Time/' \
--fields-terminated-by '\t' \
-m 1

sqoop job \
--meta-connect jdbc:hsqldb:hsql://localhost:16000/sqoop \
--list

