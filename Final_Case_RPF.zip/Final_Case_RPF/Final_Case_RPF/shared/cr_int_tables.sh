#!/bin/bash

echo "Creating cdw_sapp_d_branch table" && sleep 3

hive -f ./Final_Case_RPF/shared/hive/cr_branch.hql

hive -f ./Final_Case_RPF/shared/hive/cr_customer.hql

hive -f ./Final_Case_RPF/shared/hive/cr_credit_card.hql

hive -f ./Final_Case_RPF/shared/hive/cr_time.hql
