#!/bin/bash


hdfs dfs -rm -r /user/root/finalcase/optimized

hdfs dfs -mkdir -p /user/root/finalcase/optimized/oozie

hdfs dfs -mkdir -p /user/root/finalcase/optimized/hive

hdfs dfs -put -f ./hadoop_final/optimized/oozie/wf_* /user/root/finalcase/optimized/oozie/

hdfs dfs -put -f ./hadoop_final/optimized/hive/ins_* /user/root/finalcase/optimized/hive/

hdfs dfs -ls /user/root/finalcase/optimized/
