#!/bin/bash

echo "Deleting importBranch Job..."

sqoop job \
--meta-connect jdbc:hsqldb:hsql://localhost:16000/sqoop \
--delete importBranchOpt

echo "Deleting importCustomer Job..."

sqoop job \
--meta-connect jdbc:hsqldb:hsql://localhost:16000/sqoop \
--delete importCustomerOpt

echo "Deleting importCreditCard Job..."

sqoop job \
--meta-connect jdbc:hsqldb:hsql://localhost:16000/sqoop \
--delete importCreditCardOpt

echo "Deleting importTime Job..."

sqoop job \
--meta-connect jdbc:hsqldb:hsql://localhost:16000/sqoop \
--delete importTimeOpt

sqoop job \
--meta-connect jdbc:hsqldb:hsql://localhost:16000/sqoop \
--list