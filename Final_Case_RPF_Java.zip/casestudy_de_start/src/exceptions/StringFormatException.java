package exceptions;

public class StringFormatException extends Exception {

	public StringFormatException() {}
	
	public StringFormatException(String msg) {
		super(msg);
	}
}
