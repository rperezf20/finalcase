package runner;

import java.time.LocalDate;
import java.time.format.DateTimeParseException;
import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.List;
import java.util.Scanner;
import java.util.zip.DataFormatException;

import dao.CustomerDao;
import exceptions.IntFormatException;
import exceptions.InvalidDateRangeException;
import exceptions.StringFormatException;
import model.Customer;
import model.Transaction;


public class CustomerRunnable {
	CustomerDao cd=new CustomerDao();
	Scanner sc=new Scanner(System.in);
	List<Customer> lc=new ArrayList<Customer>();
	List<Transaction> lt=new ArrayList<Transaction>();
	
	public ArrayList<String> getCustomerCreditCard(int ssn) throws Exception{
		ArrayList<String> ccl=new ArrayList<String>();
		lc.clear();
		lc=cd.getCustomerCreditCard(ssn);
		
		if (lc.isEmpty()){
			System.out.println("\nNo Credit Card information for this client. Please try again...");
		} else {
			//System.out.println("\nRegistered Credit Cards for client with SSN " + ssn + ":\n");
			System.out.println("\nREGISTERED CREDIT CARDS FOR CLIENT WITH SSN " + ssn + ":\n");
			int i=0;
			for(Customer c: lc) {
				i++;
				ccl.add(c.getCreditCardNo());
				System.out.println(i + ") " + c.getCreditCardNo());
			}
		}
		return ccl;
	}
	
	public Customer getCustomerInfo() throws Exception{
		Integer ssn=checkSSN();

		Customer cu = cd.getCustomerInfo(ssn, checkCCN(ssn));
		
		if (cu == null) {
			System.out.println("\nNo customer information found. Please try again...");
		} else {
			printCustomerInfo(cu);
		}
		return cu;
	}
	
	public Customer getCustomerInfo(int ssn, String ccn) throws Exception{
		Customer cu = cd.getCustomerInfo(ssn, ccn);
		
		if (cu == null) {
			System.out.println("\nNo client information found. Please try again...");
		} else {
			printCustomerInfo(cu);
		}
		return cu;
	}

	public void printCustomerInfo(Customer cu) {
		System.out.println("\n\n                   CUSTOMER INFORMATION");
		System.out.println("\n 1) SSN:\t\t" + cu.getSsn());
		System.out.println(" 2) Credit Card Number:\t" + cu.getCreditCardNo());
		System.out.println(" 3) First Name:\t\t" + cu.getFirstName());
		System.out.println(" 4) Middle Name:\t" + cu.getMiddleName());
		System.out.println(" 5) Last Name:\t\t" + cu.getLastName());
		System.out.println(" 6) Street Name:\t" + cu.getStreetName());
		System.out.println(" 7) Apartment:\t\t" + cu.getAptNo());
		System.out.println(" 8) City:\t\t" + cu.getCustCity());
		System.out.println(" 9) State:\t\t" + cu.getCustState());
		System.out.println("10) Zip Code:\t\t" + cu.getCustZip());
		System.out.println("11) Country:\t\t" + cu.getCustCountry());
		System.out.println("12) Phone Number:\t" + cu.getCustPhone());
		System.out.println("13) E-mail:\t\t" + cu.getCustEmail());
		System.out.println();
	}
	
	public void updateCustomerInfo() throws Exception {
		boolean valid=true, valStringOk=false, valIntOk=false;
		String field="", val="";
		Integer op=0, vi=0;
		Customer c=getCustomerInfo();

		while(valid) {
			System.out.print("\nPlease select the value to update: ");
			try{
				op=sc.nextInt();
				if(op < 1 || op > 13){
					throw new InputMismatchException();
				}
			}
			catch(InputMismatchException emi){
				System.out.println("\nInvalid option. Please select a value from 1 to 13");
				sc.nextLine();
			}
			catch(NumberFormatException nfe){
				System.out.println("\nInvalid value. Please select a value from 1 to 13");
				sc.nextLine();
			}
			sc.nextLine();
			switch(op) {
			case 1:
			case 2:
				System.out.println("\nThis field can not be updated. Please select a value from 3 to 13...");
				break;
			case 3:
				val=checkNewValue("First Name", 40);
				field="first_name";
				valid=false;
				break;
			case 4:
				val=checkNewValue("Middle Name", 40);
				field="middle_name";
				valid=false;
				break;
			case 5:
				val=checkNewValue("Last Name", 40);
				field="last_name";
				valid=false;
				break;
			case 6:
				val=checkNewValue("Street Name", 30);
				field="street_name";
				valid=false;
				break;
			case 7:
				val=checkNewValue("Apartment", 7);
				field="apt_no";
				valid=false;
				break;
			case 8:
				while(valStringOk == false){
					val=checkNewValue("City", 30);
					try{
						if(val.matches("[a-zA-Z ]*")){
							valStringOk=true;
						}
						else{
							throw new StringFormatException("\nInvalid format value. Please use only letters for this field");
						}
					}
					catch(StringFormatException sfe){
						System.out.println(sfe.getMessage());
					}
				}
				field="cust_city";
				valid=false;
				break;
			case 9:
				while(valStringOk == false){
					val=checkNewValue("State", 30);
					try{
						if(val.matches("[a-zA-Z ]*")){
							valStringOk=true;
						}
						else{
							throw new StringFormatException("\nInvalid format value. Please use only letters for this field");
						}
					}
					catch(StringFormatException sfe){
						System.out.println(sfe.getMessage());
					}
				}
				field="cust_state";
				valid=false;
				break;
			case 10:
				while(valStringOk == false) {
					System.out.print("\nEnter the new value for 'Zip Code': ");
					try {
						val=sc.nextLine();
						if(val.matches("[0-9]+")){ 
							if(val.length() == 5) {
								valStringOk=true;
							}
							else {
								System.out.println("\nInvalid length. Please enter a 5 digits number");
							}	
						}
						else {
							throw new StringFormatException();
						}
					}
					catch(StringFormatException se) {
						System.out.println("\nInvalid Zip Code format. Please enter a number between 00000 and 99999");
					}
				}
				field="cust_zip";
				valid=false;
				break;
			case 11:
				while(valStringOk == false){
					val=checkNewValue("Country", 30);
					try{
						if(val.matches("[a-zA-Z ]*")){
								valStringOk=true;
						}
						else{
							throw new StringFormatException("\nInvalid format value. Please use only letters for this field");
						}
					}
					catch(StringFormatException se){
						System.out.println(se.getMessage());
					}
				}
				field="cust_country";
				valid=false;
				break;
			case 12:
				while(valIntOk == false) {
					System.out.print("\nEnter the new value for 'Phone Number': ");
					try {
						//vi=Integer.valueOf(sc.nextLine());
						vi=sc.nextInt();
						if(vi.toString().length()==10) {
							valIntOk=true;
						}
						else {
							System.out.println("\nInvalid Phone Number format. Please enter a 10 digits number");
						}
					}
					catch(InputMismatchException nfe) {
						System.out.println("\nInvalid Phone Number format. Please enter a 10 digits number");
						sc.nextLine();
					}
					
				}
				field="cust_phone";
				valid=false;
				break;
			case 13:
				while(valStringOk == false) {
					val=checkNewValue("E-mail", 40);
					try {
						if(val.matches("^[a-z0-9][a-z0-9-_\\.]+@([a-z]|[a-z0-9]?[a-z0-9-]+[a-z0-9])\\.[a-z0-9]{2,10}(?:\\.[a-z]{2,10})?$")){
								valStringOk=true;
						}
						else {
							throw new StringFormatException();
						}
					}
					catch(StringFormatException sfe) {
						System.out.println("\nInvalid E-mail format. Please enter a new value");
					}
				}
				valid=false;
				field="cust_email";
				break;
			} 	
		} 
		
		if (cd.updateCustomerInfo(field, val, vi, c.getSsn(), c.getCreditCardNo()) > 0) {
			System.out.println("\n\nREGISTER SUCCESSFULLY UPDATED");
			getCustomerInfo(c.getSsn(), c.getCreditCardNo());
		} else {
			System.out.println("\nUnexpected error. Please try again...");
		}		
	}
	
	public String checkNewValue(String fn, int l) {
		boolean validValue=false;
		String val="";
		while(validValue == false) {
			System.out.printf("\nEnter the new value for %s: ", fn);
			val=sc.nextLine();
			if(val.length() < 1) {
				System.out.printf("\nInvalid length. The field '%s' can not be empty. Please try again\n", fn);
			}
			else {
				if(val.length() > l) {
					System.out.printf("\nInvalid length. Please enter a %d characters value or less\n", l);
				}
				else {
					validValue=true;
				}
			}
		}
		return val;
	}
	
	public void getBillByMonthYear() throws Exception{
		int ssn=0, m=0, y=0;
		Customer cu = cd.getBillByMonthYear(ssn=checkSSN(), checkCCN(ssn), m=checkMonth(), y=checkYear());
		
		if (cu == null) {
			System.out.println("\nNo client information found. Please try again...");
		} else {
			System.out.println("\n\n        MONTHLY SMART STATEMENT");
			//System.out.println("\n\nCUSTOMER: ");
			//System.out.printf("\t%-18s%-18s%-18s\n", cu.getFirstName(), cu.getMiddleName(), cu.getLastName());
			System.out.println("\n\n" + cu.getFirstName() + " " + cu.getMiddleName() + " " + cu.getLastName());
			System.out.println("__");
			//System.out.println("\n\nADDRESS : ");
			System.out.println("\n\n" + cu.getStreetName() +  " " + cu.getAptNo());
			System.out.println(cu.getCustCity() + ", " + cu.getCustState() + ", " + cu.getCustZip());
			System.out.println(cu.getCustCountry());
			
			System.out.println("\nCREDIT CARD NUMBER: " + cu.getCreditCardNo());
			System.out.printf("\n\nTOTAL BALANCE AT %02d/%d: $%.3f\n\n", m, y, cu.getValueBill());
		}
	}
	
	public void getCustTransByDate() throws Exception{
		boolean validEntry=false;
		String d1="", d2="";
		LocalDate dt1=LocalDate.now(), dt2=LocalDate.now();
		int ssn=checkSSN(), i=0;
		String ccn = checkCCN(ssn);
		sc.nextLine();
		
		while(validEntry == false) {
			dt1=checkDate(++i);
			dt2=checkDate(++i);
			try {
				if (dt2.isBefore(dt1)) {
					throw new InvalidDateRangeException();
				}
				else {
					validEntry=true;
				}
			}
			catch(InvalidDateRangeException id) {
				System.out.println("\nInvalid range of dates. The ending date is greater than the beginning date. Please try again");
				i=0;
			}
		}
		/*
		while(validEntry == false) {
			System.out.print("\nEnter date 1 (YYYY-MM-DD): ");
			try {
				d1=sc.nextLine();
				dt1=convertDate(d1);
				if(dt1 != null) {
					validEntry=true;
				}
			}
			catch(DateTimeParseException e) {
				System.out.println("\n" + e.getMessage());
			}
		}
		validEntry=false;
		while(validEntry == false) {
			System.out.print("\nEnter date 2 (YYYY-MM-DD): ");
			try {
				d2=sc.nextLine();
				dt2=convertDate(d2);
				if(dt2 != null) {
					validEntry=true;
				}
			}
			catch(DateTimeParseException e) {
				System.out.println("\n" + e.getMessage());
			}
		}
		*/
		
		lt=cd.getCustTransByDate(ssn, ccn, d1=dt1.toString(), d2=dt2.toString());
		if(lt.isEmpty()) {
			System.out.println("\nNo information found it. Please try again...");
		}
		else {
			System.out.printf("\n\n%-35s%-30s%-10s%-3s%-10s\n","","CUSTOMER TRANSACTIONS. PERIOD ",d1," - ",d2);
			System.out.printf("\n%-17s%-19s%-19s%-12s%-14s%-33s%-17s\n",
					"Transaction ID","Transaction Date", "Credit Card No.", "SSN", "Branch Code", "Transaction Type", "Transaction Value");
			System.out.printf("%-17s%-19s%-19s%-12s%-14s%-33s%-17s\n",
					"--------------","----------------", "---------------", "---------", "-----------", "----------------", "-----------------");
			for(Transaction t: lt) {
				System.out.printf("%-17s%02d" + "-" + "%02d" + "-" + "%-13s%-19s%-12s%-14s%-33s$%,.3f\n", 
						t.getTransactionID(), t.getMonth(), t.getDay(), t.getYear(), t.getCardNo(), t.getCustSsn(),
						t.getBranchCode(), t.getTransType(), t.getTransValue());
			}

		}
		System.out.println();
	}
	
	
	public LocalDate checkDate(int n) {
		boolean validEntry=false;
		String date="";
		LocalDate dt=LocalDate.now();
		while(validEntry == false) {
			System.out.printf("\nEnter date %d (YYYY-MM-DD): ", n);
			try {
				date=sc.nextLine();
				dt=convertDate(date);
				if(dt != null) {
					validEntry=true;
				}
			}
			catch(DateTimeParseException e) {
				System.out.println("\n" + e.getMessage());
			}
		}
		return dt;
	}
	
	public LocalDate convertDate(String date) {
		return LocalDate.parse(date);
	}
	//end convertDate
	
	public boolean checkEmail(String email) {
		boolean validEmail=false;
		return validEmail;
	}
	
	public int checkSSN() {
		Integer ssn=0;
		boolean ssnOk=false;
		
		while(ssnOk == false) {
			System.out.print("\nEnter SSN: ");
			try {
				//ssn =Integer.valueOf(sc.nextLine());
				ssn =sc.nextInt();
				if (ssn.toString().length() == 9) {
					ssnOk=true;
				}
				else {
					throw new IntFormatException();
				}
			}
			catch(IntFormatException se) {
				System.out.println("\nInvalid SSN format. Please enter a 9 digits number");
			}
			catch(InputMismatchException ime) {
				System.out.println("\nInvalid SSN format. Please enter a 9 digits number");
				//sc.nextLine();
			}
			finally {
				sc.nextLine();
			}
		}
		return ssn;
	}
	//end checkSSN
	
	public String checkCCN(int ssn) throws Exception {
		boolean ccnOK=false;
		Integer ccn=0;
		
		while(ccnOK == false) {
			try{
				ArrayList<String> ccList=getCustomerCreditCard(ssn);
				if (ccList.isEmpty()){
					throw new StringFormatException();
				}
				else{
					System.out.print("\nSelect Credit Card Number: ");
					try {
						//ccn = Integer.valueOf(sc.nextLine());
						ccn = sc.nextInt();
						if(ccn < 1 || ccn > ccList.size()) {
							throw new IntFormatException();
						}
						else {
							ccnOK=true;
							return ccList.get(ccn - 1);
						}
					}
					catch(InputMismatchException ime){
						System.out.println("\nInvalid option. Please select a Credit Card from the list above");
						//sc.nextLine();
					}
					catch(IntFormatException se) {
						System.out.println("\nInvalid option. Please select a Credit Card from the list above");
						//sc.nextLine();
					}
					finally {
						sc.nextLine();
					}
				}
			}
			catch(StringFormatException se){
				System.out.println("\nNo Credit Card information registered for this customer. Please try again");
			}
		}
		return null;
	}
	//end checkCCN
	public Integer checkMonth() {
		boolean monthOk=false;
		Integer m=0;
		while (monthOk == false) {
			System.out.print("\nEnter Month: ");
			try {
				//m=Integer.valueOf(sc.nextLine());
				m=sc.nextInt();
				if(m < 1 || m > 12) {
					throw new StringFormatException();
				}
				else {
					monthOk=true;
				}
				
			}
			catch(StringFormatException se) {
				System.out.println("\nInvalid month format. Please enter a number between 1 and 12");
			}
			catch(InputMismatchException emi) {
				System.out.println("\nInvalid month format. Please enter a number between 1 and 12");
				//sc.nextLine();
			}
			finally {
				sc.nextLine();
			}
		}
		return m;
	}
	//end checkMonth
	public Integer checkYear() {
		boolean yearOk=false;
		Integer y=0;
		while (yearOk == false) {
			System.out.print("\nEnter Year: ");
			try {
				//y=Integer.valueOf(sc.nextLine());
				y=sc.nextInt();
				if(y >= 1900) {
					yearOk=true;
					
				}
				else {
					throw new StringFormatException();
				}
				
			}
			catch(StringFormatException se) {
				System.out.println("\nInvalid Year format. Please enter a 4 digits number above 1900");
			}
			catch(InputMismatchException emi) {
				System.out.println("\nInvalid Year format. Please enter a 4 digits number above 1900");
				//sc.nextLine();
			}
			finally {
				sc.nextLine();
			}
		}
		return y;
	}
	//end checkYear
}
