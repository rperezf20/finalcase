package model;

public class Customer {
	private double valueBill;
	private int ssn, custPhone;
	private String firstName, middleName, lastName, creditCardNo, custEmail;
	private String aptNo, streetName, custCity, custState, custCountry, custZip;
	
	public String getFirstName() {
		return firstName;
	}
	
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	
	public String getMiddleName() {
		return middleName;
	}
	
	public double getValueBill() {
		return valueBill;
	}
	
	public void setValueBill(double valueBill) {
		this.valueBill = valueBill;
	}
	
	public void setMiddleName(String middleName) {
		this.middleName = middleName;
	}
	
	public String getLastName() {
		return lastName;
	}
	
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	
	public String getCreditCardNo() {
		return creditCardNo;
	}
	
	public void setCreditCardNo(String creditCardNo) {
		this.creditCardNo = creditCardNo;
	}
	
	public String getCustEmail() {
		return custEmail;
	}
	
	public void setCustEmail(String custEmail) {
		this.custEmail = custEmail;
	}
	
	public int getSsn() {
		return ssn;
	}
	
	public void setSsn(int ssn) {
		this.ssn = ssn;
	}
	
	public int getCustPhone() {
		return custPhone;
	}
	
	public void setCustPhone(int custPhone) {
		this.custPhone = custPhone;
	}
	
	public String getAptNo() {
		return aptNo;
	}
	
	public void setAptNo(String aptNo) {
		this.aptNo = aptNo;
	}
	
	public String getStreetName() {
		return streetName;
	}
	
	public void setStreetName(String streetName) {
		this.streetName = streetName;
	}
	
	public String getCustCity() {
		return custCity;
	}
	
	public void setCustCity(String custCity) {
		this.custCity = custCity;
	}
	
	public String getCustState() {
		return custState;
	}
	
	public void setCustState(String custState) {
		this.custState = custState;
	}
	
	public String getCustCountry() {
		return custCountry;
	}
	
	public void setCustCountry(String custCountry) {
		this.custCountry = custCountry;
	}
	
	public String getCustZip() {
		return custZip;
	}
	
	public void setCustZip(String custZip) {
		this.custZip = custZip;
	}
}
