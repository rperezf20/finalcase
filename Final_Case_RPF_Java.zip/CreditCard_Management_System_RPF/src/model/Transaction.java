package model;

public class Transaction{
	protected int transactionID, day, month, year, branchCode, custSsn; 
	protected int totalTranNum;
	protected double transValue, totalTranValue;
	protected String cardNo, transType, state;
	
	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public int getTransactionID() {
		return transactionID;
	}
	
	public void setTransactionID(int transactionID) {
		this.transactionID = transactionID;
	}
	
	public int getDay() {
		return day;
	}
	
	public int getTotalTranNum() {
		return totalTranNum;
	}

	public void setTotalTranNum(int totalTranNum) {
		this.totalTranNum = totalTranNum;
	}

	public double getTotalTranValue() {
		return totalTranValue;
	}

	public void setTotalTranValue(double totalTranValue) {
		this.totalTranValue = totalTranValue;
	}

	public void setDay(int day) {
		this.day = day;
	}
	
	public int getMonth() {
		return month;
	}
	
	public void setMonth(int month) {
		this.month = month;
	}
	
	public int getYear() {
		return year;
	}
	
	public void setYear(int year) {
		this.year = year;
	}
	
	public int getBranchCode() {
		return branchCode;
	}
	
	public void setBranchCode(int branchCode) {
		this.branchCode = branchCode;
	}
	
	public int getCustSsn() {
		return custSsn;
	}
	
	public void setCustSsn(int custSsn) {
		this.custSsn = custSsn;
	}
	
	public String getCardNo() {
		return cardNo;
	}
	
	public void setCardNo(String cardNo) {
		this.cardNo = cardNo;
	}
	
	public String getTransType() {
		return transType;
	}
	
	public void setTransType(String transType) {
		this.transType = transType;
	}
	
	public double getTransValue() {
		return transValue;
	}
	
	public void setTransValue(double transValue) {
		this.transValue = transValue;
	}
}