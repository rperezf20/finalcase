package exceptions;

public class StateNotFoundException extends Exception{
	public StateNotFoundException() {}
	
	public StateNotFoundException(String msg) {
		super(msg);
	}
}