package exceptions;

public class IntFormatException extends Exception{
	public IntFormatException() {}
	
	public IntFormatException(String msg) {
		super(msg);
	}
}
