package exceptions;

public class InvalidDateRangeException extends Exception{
	public InvalidDateRangeException() {}
	
	public InvalidDateRangeException(String msg) {
		super(msg);
	}
}
