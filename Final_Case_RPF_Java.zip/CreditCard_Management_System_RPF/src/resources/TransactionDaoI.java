package resources;

import java.sql.SQLException;
import java.util.List;

import model.Transaction;


public interface TransactionDaoI {
	
	final static String getTransByZipCode="SELECT * FROM cdw_sapp_customer cus JOIN cdw_sapp_creditcard cc"
			+ " ON cus.credit_card_no=cc.credit_card_no"
			+ " AND cus.ssn=cc.cust_ssn"
			+ " AND cus.cust_zip=?"
			+ " AND cc.month=?"
			+ " AND cc.year=?"
			+ " ORDER BY cc.day DESC";
	
	final static String getTransType="SELECT DISTINCT(transaction_type)"
			+ " FROM cdw_sapp_creditcard";
	
	final static String getTotalTransByType="SELECT COUNT(transaction_type), SUM(transaction_value) "
			+ "FROM cdw_sapp_creditcard "
			+ " WHERE transaction_type=?"
			+ "GROUP BY transaction_type ";
	
	final static String getStates="SELECT DISTINCT(cust_state) FROM cdw_sapp_customer ORDER BY 1";
	
	final static String getTotalTransByState="SELECT COUNT(br.branch_state), SUM(cc.transaction_value), br.branch_state"
			+ " FROM cdw_sapp_branch br JOIN cdw_sapp_creditcard cc"
			+ " ON br.branch_code = cc.branch_code"
			+ " WHERE br.branch_state=?"
			+ " GROUP BY br.branch_state";

	
	List<Transaction> getTransByZipCode(String zipCode, int year, int month) throws Exception;
	
	List<Transaction> getTransType() throws Exception;
	
	Transaction getTotalTransByType(String transType) throws Exception;
	
	List<Transaction> getStates() throws Exception;
	
	Transaction getTotalTransByState(String state) throws Exception;
	
}
