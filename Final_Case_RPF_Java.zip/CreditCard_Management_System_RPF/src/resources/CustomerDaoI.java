package resources;

import java.util.List;
import model.Customer;
import model.Transaction;

public interface CustomerDaoI {
		
	final static String getCustomerCC="SELECT credit_card_no FROM cdw_sapp_customer "
			+ "WHERE ssn=?";
	
	final static String getCustomerInfo="SELECT * FROM cdw_sapp_customer "
			+ "WHERE ssn=?"
			+ "  AND credit_card_no=?";
	
	final static String updateCustomerInfoI="UPDATE cdw_sapp_customer "
			+ "SET ";
	final static String updateCustomerInfoII="=? WHERE ssn=?"
			+ "  AND credit_card_no=?";
	
	final static String getBillByMonthYear="SELECT SUM(cc.transaction_value), c.first_name, c.middle_name, c.last_name, "
			+ "c.street_name, c.apt_no, c.cust_city, c.cust_state, c.cust_country, c.cust_zip, c.credit_card_no " + 
			"FROM cdw_sapp_customer c " + 
			"JOIN cdw_sapp_creditcard cc ON c.ssn = cc.cust_ssn AND c.credit_card_no = cc.credit_card_no " + 
			"WHERE cc.cust_ssn=? " + 
			"  AND cc.credit_card_no=? " + 
			"  AND cc.month=? " + 
			"  AND cc.year=? " + 
			"GROUP BY cc.credit_card_no, cc.cust_ssn";
	
	final static String getCustTransByDate="SELECT * " + 
			"FROM cdw_sapp_creditcard " + 
			"WHERE cust_ssn=?" + 
			"  AND credit_card_no=?" + 
			"  AND STR_TO_DATE(CONCAT(month,'.',day,'.',year)"
			      
			+ ", GET_FORMAT(DATE, 'USA'))" + 
			"  BETWEEN ? AND ? " + 
			"ORDER BY year, month, day";
	
	
	List<Customer> getCustomerCreditCard(int ssn) throws Exception;
	
	Customer getCustomerInfo(int ssn, String ccn) throws Exception;
	
	int updateCustomerInfo(String f, String value, int vi, int ssn, String ccn) throws Exception;
	
	Customer getBillByMonthYear(int ssn, String ccn, int m, int y) throws Exception;
	
	List<Transaction> getCustTransByDate(int ssn, String ccn, String d1, String d2) throws Exception;

}
