package dao;

import java.util.ArrayList;
import java.util.List;
import model.Transaction;

import model.Customer;
import resources.CustomerDaoI;

public class CustomerDao extends DBConnection implements CustomerDaoI{
	List<Customer> lc=new ArrayList<Customer>();
	List<Transaction> lt=new ArrayList<Transaction>();
	
	public Customer getCustomerInfo(int ssn, String ccn) throws Exception {
		myconnection();
		
		ps=con.prepareStatement(getCustomerInfo);
		ps.setInt(1, ssn);
		ps.setString(2, ccn);	
		rs=ps.executeQuery();
		
		if (rs.next()) {
			Customer c=new Customer();
			c.setFirstName(rs.getString("first_name"));
			c.setMiddleName(rs.getString("middle_name"));
			c.setLastName(rs.getString("last_name"));
			c.setCreditCardNo(rs.getString("credit_card_no"));
			c.setAptNo(rs.getString("apt_no"));
			c.setStreetName(rs.getString("street_name"));
			c.setCustCity(rs.getString("cust_city"));
			c.setCustState(rs.getString("cust_state"));
			c.setCustCountry(rs.getString("cust_country"));
			c.setCustZip(rs.getString("cust_zip"));
			c.setCustEmail(rs.getString("cust_email"));
			c.setSsn(rs.getInt("ssn"));
			c.setCustPhone(rs.getInt("cust_phone"));
			
			return c;
		}
		
		return null;
	}
	
	public List<Customer> getCustomerCreditCard(int ssn) throws Exception {
		myconnection();
		
		ps=con.prepareStatement(getCustomerCC);
		ps.setInt(1, ssn);
		rs=ps.executeQuery();
		//lc.clear();
		
		while(rs.next()) {
			Customer c=new Customer();
			c.setCreditCardNo(rs.getString("credit_card_no"));
			
			lc.add(c);
		}
		return lc;
	}
	
	public int updateCustomerInfo(String f, String v, int vi, int ssn, String ccn) throws Exception {
		myconnection();
		
		//System.out.println("Connecting...");
		//UPDATE table SET f=v WHERE ..ccn.
		ps=con.prepareStatement(updateCustomerInfoI + f + updateCustomerInfoII);
		
		if (f=="cust_phone") {
			ps.setInt(1, vi);
		} else {
			ps.setString(1, v);
		}
		ps.setInt(2, ssn);
		ps.setString(3, ccn);
		//System.out.println("\n\n" + ps.toString());
		return ps.executeUpdate();
	}
	
	public Customer getBillByMonthYear(int ssn, String ccn, int m, int y) throws Exception {
		myconnection();
		//System.out.println("Connecting...");
		
		ps=con.prepareStatement(getBillByMonthYear);
		ps.setInt(1, ssn);
		ps.setString(2, ccn);
		ps.setInt(3, m);
		ps.setInt(4, y);
		
		//System.out.println("Executing SQL statement...\n");
		
		rs=ps.executeQuery();
		
		if (rs.next()) {
			Customer c=new Customer();
			c.setValueBill(rs.getDouble(1));
			c.setFirstName(rs.getString("first_name"));
			c.setMiddleName(rs.getString("middle_name"));
			c.setLastName(rs.getString("last_name"));
			c.setStreetName(rs.getString("street_name"));
			c.setAptNo(rs.getString("apt_no"));
			c.setCustCity(rs.getString("cust_city"));
			c.setCustState(rs.getString("cust_state"));
			c.setCustCountry(rs.getString("cust_country"));
			c.setCustZip(rs.getString("cust_zip"));
			c.setCreditCardNo(rs.getString("credit_card_no"));
			
			return c;
		}
		return null;		
	}
	
	public List<Transaction> getCustTransByDate(int ssn, String ccn, String d1, String d2) throws Exception {
		myconnection();
		
		ps=con.prepareStatement(getCustTransByDate);
		ps.setInt(1, ssn);
		ps.setString(2, ccn);
		ps.setString(3, d1);
		ps.setString(4, d2);
		rs=ps.executeQuery();
		lt.clear();
		
		while(rs.next()) {
			Transaction t=new Transaction();
			t.setTransactionID(rs.getInt("transaction_id"));
			t.setDay(rs.getInt("day"));
			t.setMonth(rs.getInt("month"));
			t.setYear(rs.getInt("year"));
			t.setCardNo(rs.getString("credit_card_no"));
			t.setCustSsn(rs.getInt("cust_ssn"));
			t.setBranchCode(rs.getInt("branch_code"));
			t.setTransType(rs.getString("transaction_type"));
			t.setTransValue(rs.getDouble("transaction_value"));
			
			lt.add(t);
		}
		return lt;
	}
}
