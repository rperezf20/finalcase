package dao;

import java.util.ArrayList;
import java.util.List;
import model.Transaction;
import resources.TransactionDaoI;

public class TransactionDao extends DBConnection implements TransactionDaoI {
	List<Transaction> lt=new ArrayList<Transaction>();
	
	public List<Transaction> getTransByZipCode(String zipCode, int month, int year) throws Exception{	
		myconnection();
	
		ps = con.prepareStatement(getTransByZipCode);
		ps.setString(1, zipCode);
		ps.setInt(2, month);
		ps.setInt(3, year);
		rs = ps.executeQuery();
		lt.clear();
		
		while (rs.next()) {
			Transaction t = new Transaction();
			
			t.setTransactionID(rs.getInt("transaction_id"));
			t.setDay(rs.getInt("day"));
			t.setMonth(rs.getInt("month"));
			t.setYear(rs.getInt("year"));
			t.setCardNo(rs.getString("credit_card_no"));
			t.setCustSsn(rs.getInt("cust_ssn"));
			t.setBranchCode(rs.getInt("branch_code"));
			t.setTransType(rs.getString("transaction_type"));
			t.setTransValue(rs.getDouble("transaction_value"));
			
			lt.add(t);
		}		
		return lt;
	}
	
	
	public List<Transaction> getTransType() throws Exception {
		myconnection();
		
		ps = con.prepareStatement(getTransType);
		rs = ps.executeQuery();
		lt.clear();
		
		while(rs.next()) {
			Transaction t= new Transaction();
			t.setTransType(rs.getString(1));
			
			lt.add(t);
		}		
		return lt;
	}
	
	
	public Transaction getTotalTransByType(String transType) throws Exception{
		myconnection();
		ps = con.prepareStatement(getTotalTransByType);
		ps.setString(1, transType);
		rs = ps.executeQuery();
		
		if (rs.next()) {
			Transaction t = new Transaction();
			t.setTotalTranNum(rs.getInt(1));
			t.setTotalTranValue(rs.getInt(2));
			return t;
		}		
		return null;
	}
	
	public List<Transaction> getStates() throws Exception {
		myconnection();
		ps = con.prepareStatement(getStates);
		rs = ps.executeQuery();
		lt.clear();
		while(rs.next()) {
			Transaction t= new Transaction();
			t.setState(rs.getString(1));
			lt.add(t);
		}
		return lt;
	}
	
	public Transaction getTotalTransByState(String state) throws Exception{
		myconnection();
		
		ps = con.prepareStatement(getTotalTransByState);
		ps.setString(1, state);
		rs = ps.executeQuery();
		
		if (rs.next()) {
			Transaction t = new Transaction();
			t.setTotalTranNum(rs.getInt(1));
			t.setTotalTranValue(rs.getInt(2));
			return t;
		}		
		return null;
	}

}