package runner;


import java.io.IOException;
import java.sql.SQLException;
import java.util.InputMismatchException;
import java.util.Scanner;


public class Main  {
	static Scanner sc;
	public static void main(String[] args) throws Exception {		
		CustomerRunnable cr=new CustomerRunnable();
		TransactionRunnable tr = new TransactionRunnable();
		int option=0;
		sc=new Scanner(System.in);
		
		while (option != 8) {
			menu();
			//option=sc.nextInt();
			
			try {
				//option=Integer.valueOf(sc.nextLine());
				option=sc.nextInt();
				
				if(option < 1 || option > 8) {
					throw new InputMismatchException();
				}
			}
			catch(InputMismatchException ime) {
				System.out.println("\nInvalid option. Please select a value from 1 to 8\n");
				//sc.nextLine();
			}
			catch(NumberFormatException ime) {
				System.out.println("\nInvalid option. Please select a value from 1 to 8\n");
				//sc.nextLine();
			}
			finally {
				sc.nextLine();
			}
			
			
			try {
				switch(option) {
				case 1:
					tr.getTransByZipCode();
					break;
				case 2:
					tr.getTotalByType();
					break;
				case 3:
					tr.getTotalTransByState();
					break;
				case 4:
					cr.getCustomerInfo();
					break;
				case 5:
					cr.updateCustomerInfo();				
					break;
				case 6:
					cr.getBillByMonthYear();
					break;
				case 7:				
					cr.getCustTransByDate();
					break;
				case 8:
					break;
				}
			}
			catch(IOException e) {}
			catch(SQLException e) {}
			Runtime.getRuntime().exec("clear");
		}
	}
	
	public static void menu() {
		System.out.println("\n\nC R E D I T   C A R D   M A N A G E M E N T   S Y S T E M");
		//System.out.println("_________________________________________________________");
		//System.out.println("---------------------------------------------------------");
		System.out.println("\n1. Transactions by Zip Code");
		System.out.println("2. Transactions and Total by Type");
		System.out.println("3. Transactions and Total by branches in a state");
		System.out.println("4. Print customer information");
		System.out.println("5. Update customer information");
		System.out.println("6. Generate monthly bill");
		System.out.println("7. Transaction History by date range");
		System.out.println("8. Quit");
		System.out.print("\nPlease select an option: ");
	}	
}
