package runner;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.InputMismatchException;
import java.util.List;
import java.util.Scanner;

import dao.TransactionDao;
import exceptions.IntFormatException;
import exceptions.StateNotFoundException;
import exceptions.StringFormatException;
import model.Transaction;

public class TransactionRunnable{
	List<Transaction> ltr=new ArrayList<Transaction>();
	TransactionDao td=new TransactionDao();
	Scanner sc=new Scanner(System.in);

    public void getTransByZipCode() throws Exception{
    	String zc="";
    	int m=0, y=0;
    	ltr = td.getTransByZipCode(zc=checkZipCode(), m=checkMonth(), y=checkYear());
    	
		//print the information within the loop
		if (ltr.isEmpty()) {
			System.out.println("\nNo information found. Please try again...");
		} else {
			System.out.printf("\n%-35s%-37s%-5s%-4s%02d%-1s%04d\n","","REGISTERED TRANSACTIONS FOR ZIP CODE ",zc," IN ",m,"/",y);
					//,zc," IN ",m,"/",y);
			System.out.printf("\n%-17s%-19s%-19s%-12s%-14s%-33s%-17s\n",
					"Transaction ID","Transaction Date", "Credit Card No.", "SSN", "Branch Code", "Transaction Type", "Transaction Value");
			System.out.printf("%-17s%-19s%-19s%-12s%-14s%-33s%-17s\n",
					"--------------","----------------", "---------------", "---------", "-----------", "----------------", "-----------------");
		                                              
			for(Transaction t: ltr) {
				System.out.printf("%-17s%02d" + "-" + "%02d" + "-" + "%-13s%-19s%-12s%-14s%-33s$%,.3f\n", 
						t.getTransactionID(), t.getMonth(), t.getDay(), t.getYear(), t.getCardNo(), t.getCustSsn(),
						t.getBranchCode(), t.getTransType(), t.getTransValue());
			}
		}
		//System.out.println();
		//System.out.print("\033[H\033[2J");
	    System.out.flush();
	}
	
	public ArrayList<String> getTransType() throws Exception{
		ArrayList<String> ttList=new ArrayList<String>();
		ltr = td.getTransType();
		
		if (ltr.isEmpty()) {
			System.out.println("\nNo information found. Please try again...");
		} else {
			System.out.printf("\n%-27s\n", "Availabe Transaction Types:");
			System.out.printf("%-27s\n",
					"---------------------------");
			int i=1;
			for(Transaction t: ltr) {
				ttList.add(t.getTransType());
				System.out.println(i + ") " + t.getTransType());
				i++;
			}
		}
		return ttList;
	}
	
	public void getTotalByType() throws Exception{
		boolean validType=false;
		Integer tranType=0;
		ArrayList<String> ttl=new ArrayList<String>();
		
		while (validType==false){
			ttl=getTransType();
			System.out.print("\nSelect Transaction Type: ");
			try{
				//tranType=Integer.valueOf(sc.nextLine());
				tranType=sc.nextInt();
				if (tranType < 1 || tranType > ttl.size()){
					throw new InputMismatchException();
				}
				else{
					validType=true;
					Transaction tr = td.getTotalTransByType(ttl.get(tranType - 1));
					//tl.get(tranType);
					if(tr == null) {
						System.out.println("\nNo information for transaction type '" + ttl.get(tranType - 1) + "'. Try again...");
					} else {
						System.out.printf("\n\n%-10s%-30s%-30s\n","","TRANSACTION DETAILS BY TYPE -", ttl.get(tranType -1));
						System.out.println("\n\nTOTAL NUMBER OF TRANSACTIONS: " + tr.getTotalTranNum());
						System.out.printf("\n\nTOTAL VALUE OF TRANSACTIONS : $%,.3f\n\n", tr.getTotalTranValue());
					}
				}
			}
			catch(InputMismatchException ime){
				System.out.println("\nInvalid Transaction Type. Please select a value from 1 to " + ttl.size());
				//sc.nextLine();
			}
			finally {
				sc.nextLine();
			}
		}
	}
	
	public HashSet<String> getStates() throws Exception {
		HashSet<String> setStates=new HashSet<String>();
		ltr=td.getStates();
		System.out.printf("\n%-31s%-12s\n\n","","AVAILABLE STATES");
		
		int i=1;
		
		for(Transaction t : ltr) {
			setStates.add(t.getState());
			System.out.print(t.getState() + " ");
			i++;
			if (i>25){
				System.out.println();
				i=1;
			}
		}
		return setStates;
	}
	
	
	public void getTotalTransByState() throws Exception{
	
		String state=checkState();
		Transaction tr = td.getTotalTransByState(state);
		
		if (tr == null) {
			System.out.println("\nNo information found for '" + state + "'. Try again...");
		} else {
			System.out.printf("\n\n%-10s%-31s%-30s\n","","TRANSACTION DETAILS BY STATE -", state.toUpperCase());
			System.out.println("\n\nTOTAL NUMBER OF TRANSACTIONS: " + tr.getTotalTranNum());
			System.out.printf("\nTOTAL VALUE OF TRANSACTIONS : $%,.3f\n\n", tr.getTotalTranValue());
		}
	}
	
	public String checkState() throws Exception{
		boolean stateOk=false;
		String state="";
		try {
		HashSet<String> sst=getStates();
		
			if(sst.isEmpty()) {
				throw new IndexOutOfBoundsException("Unexpected error. No registered states in the data base");
			}
			else {
				while(stateOk == false) {
					System.out.print("\n\nEnter state: ");
					try {
						state = sc.nextLine();
						if(sst.contains(state.toUpperCase())) {
							stateOk=true;
							return state;
						}
						else {
							throw new StateNotFoundException("Invalid state. Please enter a valid value from the list of states");
						}							
					}
					catch(StateNotFoundException se) {
						System.out.println("\n" + se.getMessage());
						sst=getStates();
					}
				}
			}
		}
		catch(IndexOutOfBoundsException e) {
			System.out.println(e.getMessage());
		}
		return null;
	}
	
	public String checkZipCode(){
		String zc="";
		boolean zipOk=false;
		
		while (zipOk == false) {
			System.out.print("\nEnter Zip Code: ");
			try {
				zc=sc.nextLine();
				if (zc.matches("[0-9]+") && zc.length()==5) {
					zipOk=true;
				}
				else {
					throw new StringFormatException("\nInvalid Zip Code format. Please enter a number between 00000 and 99999");
				}
			}
			catch(StringFormatException se) {
				System.out.println(se.getMessage());
			}
		}
		return zc;
	}
	
	public Integer checkMonth() {
		boolean monthOk=false;
		Integer m=0;
		while (monthOk == false) {
			System.out.print("\nEnter Month: ");
			try {
				m=sc.nextInt();
				//m=Integer.valueOf(sc.nextLine());
				if(m < 1 || m > 12) {
					throw new IntFormatException();
				}
				else {
					monthOk=true;
				}
			}
			catch(IntFormatException ife) {
				System.out.println("\nInvalid month format. Please enter a number between 1 and 12");
			}
			catch(InputMismatchException nfe) {
				System.out.println("\nInvalid month format. Please enter a number between 1 and 12");
			}
			finally {
				sc.nextLine();
			}
		}
		return m;
	}
	
	public Integer checkYear() {
		boolean yearOk=false;
		Integer y=0;
		while (yearOk == false) {
			System.out.print("\nEnter Year: ");
			try {
				y=sc.nextInt();
				//y=Integer.valueOf(sc.nextLine());
				if(y >= 1900 && y.toString().length()==4) {
					yearOk=true;	
				}
				else {
					throw new IntFormatException();
				}
			}
			catch(IntFormatException ife) {
				System.out.println("\nInvalid Year format. Please enter a 4 digits number above 1900");
			}
			catch(InputMismatchException ime) {
				System.out.println("\nInvalid Year format. Please enter a 4 digits number above 1900");
			}
			finally {
				sc.nextLine();
			}
		}
		return y;
	}
}
